import { Router } from "express";
import { randomUUID } from "crypto";
import { readJson, writeJson } from "../lib/storage";

const router = Router();
const ADMIN_PASSWORD = "Maraca";

interface EstrangeiroUser {
  id: string;
  name: string;
  discordNick: string;
  password: string;
  createdAt: string;
}

interface AuditEntry {
  type: "register" | "login";
  userId: string;
  name: string;
  discordNick?: string;
  timestamp: string;
}

interface TabItem {
  id: string;
  label: string;
  entries?: Array<{
    id: string;
    text: string;
    timestamp: string;
  }>;
  content?: string;
}

interface UserData {
  tabs: TabItem[];
}

async function getUsers(): Promise<EstrangeiroUser[]> {
  const data = await readJson<{ users: EstrangeiroUser[] }>("estrangeiros/users.json");
  return data?.users ?? [];
}

async function saveUsers(users: EstrangeiroUser[]): Promise<void> {
  await writeJson("estrangeiros/users.json", { users });
}

async function getAudit(): Promise<AuditEntry[]> {
  const data = await readJson<{ log: AuditEntry[] }>("estrangeiros/audit.json");
  return data?.log ?? [];
}

async function appendAudit(entry: AuditEntry): Promise<void> {
  const log = await getAudit();
  log.push(entry);
  await writeJson("estrangeiros/audit.json", { log });
}

const DEFAULT_TABS: TabItem[] = [
  { id: "t1", label: "Anotações", entries: [] },
  { id: "t2", label: "Enigmas", entries: [] },
  { id: "t3", label: "Teorias", entries: [] },
];

router.post("/estrangeiros/register", async (req, res) => {
  const { name, discordNick, password } = req.body as { name?: string; discordNick?: string; password?: string };
  if (!name || name.trim().length < 2) return res.status(400).json({ error: "Nome deve ter pelo menos 2 caracteres" });
  if (!discordNick || discordNick.trim().length < 2) return res.status(400).json({ error: "Nick do Discord inválido" });
  if (!password || password.length < 4) return res.status(400).json({ error: "Senha deve ter pelo menos 4 caracteres" });

  const users = await getUsers();
  const exists = users.find(u => u.name.toLowerCase() === name.trim().toLowerCase());
  if (exists) return res.status(409).json({ error: "Já existe um cadastro com esse nome" });

  const newUser: EstrangeiroUser = {
    id: randomUUID(),
    name: name.trim(),
    discordNick: discordNick.trim(),
    password,
    createdAt: new Date().toISOString(),
  };
  users.push(newUser);
  await saveUsers(users);
  await writeJson(`estrangeiros/${newUser.id}/data.json`, { tabs: DEFAULT_TABS });
  await appendAudit({ type: "register", userId: newUser.id, name: newUser.name, discordNick: newUser.discordNick, timestamp: new Date().toISOString() });

  const { password: _pw, ...safeUser } = newUser;
  return res.json({ user: safeUser });
});

router.post("/estrangeiros/login", async (req, res) => {
  const { name, password } = req.body as { name?: string; password?: string };
  if (!name) return res.status(400).json({ error: "Nome obrigatório" });
  if (!password) return res.status(400).json({ error: "Senha obrigatória" });

  const users = await getUsers();
  const user = users.find(u => u.name.toLowerCase() === name.trim().toLowerCase());
  if (!user) return res.status(404).json({ error: "Nenhum cadastro encontrado com esse nome" });
  if (user.password !== password) return res.status(401).json({ error: "Senha incorreta" });

  await appendAudit({ type: "login", userId: user.id, name: user.name, timestamp: new Date().toISOString() });
  const { password: _pw, ...safeUser } = user;
  return res.json({ user: safeUser });
});

router.get("/estrangeiros/:userId/data", async (req, res) => {
  const { userId } = req.params;
  const data = await readJson<UserData>(`estrangeiros/${userId}/data.json`);
  return res.json(data ?? { tabs: DEFAULT_TABS });
});

router.put("/estrangeiros/:userId/data", async (req, res) => {
  const { userId } = req.params;
  const { tabs } = req.body as { tabs?: TabItem[] };
  if (!Array.isArray(tabs)) return res.status(400).json({ error: "Dados inválidos" });
  await writeJson(`estrangeiros/${userId}/data.json`, { tabs });
  return res.json({ ok: true });
});

router.post("/estrangeiros/admin", async (req, res) => {
  const { password } = req.body as { password?: string };
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Acesso negado" });

  const [users, audit] = await Promise.all([getUsers(), getAudit()]);

  const usersWithData = await Promise.all(
    users.map(async u => {
      const data = await readJson<UserData>(`estrangeiros/${u.id}/data.json`);
      return { ...u, tabs: data?.tabs ?? DEFAULT_TABS };
    })
  );

  return res.json({ users: usersWithData, audit });
});

router.put("/estrangeiros/admin/users/:userId/password", async (req, res) => {
  const { password, newPassword } = req.body as { password?: string; newPassword?: string };
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Acesso negado" });
  if (!newPassword || newPassword.length < 4) return res.status(400).json({ error: "Senha deve ter pelo menos 4 caracteres" });

  const { userId } = req.params;
  const users = await getUsers();
  const idx = users.findIndex(u => u.id === userId);
  if (idx === -1) return res.status(404).json({ error: "Usuário não encontrado" });

  users[idx]!.password = newPassword;
  await saveUsers(users);
  return res.json({ ok: true });
});

router.delete("/estrangeiros/admin/users/:userId", async (req, res) => {
  const { password } = req.body as { password?: string };
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Acesso negado" });

  const { userId } = req.params;
  const users = await getUsers();
  const filtered = users.filter(u => u.id !== userId);
  if (filtered.length === users.length) return res.status(404).json({ error: "Usuário não encontrado" });

  await saveUsers(filtered);
  return res.json({ ok: true });
});

export default router;
