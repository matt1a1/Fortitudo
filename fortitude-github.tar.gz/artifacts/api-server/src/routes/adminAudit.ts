import { Router } from "express";
import { memAudit, addMemAudit } from "../store";
import { readJson, writeJson } from "../lib/storage";

const router = Router();
const ADMIN_PASSWORD = "Maraca";

router.post("/admin/audit", async (req, res) => {
  const { profileId, eventType, description } = req.body as {
    profileId?: string; eventType?: string; description?: string;
  };
  if (!profileId || !eventType || !description) return res.status(400).json({ error: "Campos obrigatórios ausentes" });

  addMemAudit(profileId, eventType, description);

  try {
    const existing = await readJson<typeof memAudit>("audit/log.json") ?? [];
    existing.unshift({ id: Date.now(), profileId, eventType, description, createdAt: new Date() });
    if (existing.length > 500) existing.splice(500);
    await writeJson("audit/log.json", existing);
  } catch {}

  return res.json({ ok: true });
});

router.post("/admin/audit/list", async (req, res) => {
  const { password } = req.body as { password?: string };
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Acesso negado" });

  const stored = await readJson<typeof memAudit>("audit/log.json");
  return res.json(stored ?? memAudit.slice(0, 500));
});

export default router;
