import { Router } from "express";
import { VALID_PROFILES, memData } from "../store";
import { readJson, writeJson } from "../lib/storage";

const router = Router();

router.get("/profiles/:profileId/data", async (req, res) => {
  const { profileId } = req.params;
  if (!VALID_PROFILES.includes(profileId)) return res.status(400).json({ error: "Perfil inválido" });

  const stored = await readJson<Record<string, unknown>>(`profiles/${profileId}/data.json`);
  if (stored) {
    memData.set(profileId, stored);
    return res.json(stored);
  }
  return res.json(memData.get(profileId) ?? {});
});

router.put("/profiles/:profileId/data", async (req, res) => {
  const { profileId } = req.params;
  if (!VALID_PROFILES.includes(profileId)) return res.status(400).json({ error: "Perfil inválido" });

  const data = req.body as Record<string, unknown>;
  memData.set(profileId, data);
  await writeJson(`profiles/${profileId}/data.json`, data);
  return res.json({ ok: true });
});

export default router;
