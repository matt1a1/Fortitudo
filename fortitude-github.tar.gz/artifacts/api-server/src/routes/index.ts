import { Router, type IRouter } from "express";
import healthRouter from "./health";
import profileDataRouter from "./profileData";
import profilePasswordsRouter from "./profilePasswords";
import adminBackupRouter from "./adminBackup";
import adminAuditRouter from "./adminAudit";
import adminPasswordsRouter from "./adminPasswords";
import estrangeirosRouter from "./estrangeiros";

const router: IRouter = Router();

router.use(healthRouter);
router.use(profileDataRouter);
router.use(profilePasswordsRouter);
router.use(adminBackupRouter);
router.use(adminAuditRouter);
router.use(adminPasswordsRouter);
router.use(estrangeirosRouter);

export default router;
