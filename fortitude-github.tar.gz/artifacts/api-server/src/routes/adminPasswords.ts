import { Router } from "express";
import { VALID_PROFILES, DEFAULT_PASSWORDS, memPasswords } from "../store";
import { readJson, writeJson } from "../lib/storage";

const router = Router();
const ADMIN_PASSWORD = "Maraca";

async function getPassword(profileId: string): Promise<string> {
  const stored = await readJson<{ password: string }>(`profiles/${profileId}/password.json`);
  if (stored?.password) return stored.password;
  return memPasswords.get(profileId) ?? DEFAULT_PASSWORDS[profileId] ?? profileId;
}

router.post("/admin/passwords", async (req, res) => {
  const { password } = req.body as { password?: string };
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Acesso negado" });

  const result: Record<string, string> = {};
  await Promise.all(VALID_PROFILES.map(async id => {
    result[id] = await getPassword(id);
  }));
  return res.json(result);
});

router.put("/admin/passwords/:profileId", async (req, res) => {
  const { profileId } = req.params;
  if (!VALID_PROFILES.includes(profileId)) return res.status(400).json({ error: "Perfil inválido" });
  const { password, newPassword } = req.body as { password?: string; newPassword?: string };
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Acesso negado" });
  if (!newPassword || newPassword.length < 4) return res.status(400).json({ error: "Senha deve ter pelo menos 4 caracteres" });

  memPasswords.set(profileId, newPassword);
  await writeJson(`profiles/${profileId}/password.json`, { password: newPassword });
  return res.json({ ok: true });
});

export default router;
