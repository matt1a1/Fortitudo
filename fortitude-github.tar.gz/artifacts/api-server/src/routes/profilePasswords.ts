import { Router } from "express";
import { VALID_PROFILES, DEFAULT_PASSWORDS, memPasswords } from "../store";
import { readJson, writeJson } from "../lib/storage";

const router = Router();

async function getCurrentPassword(profileId: string): Promise<string> {
  const stored = await readJson<{ password: string }>(`profiles/${profileId}/password.json`);
  if (stored?.password) {
    memPasswords.set(profileId, stored.password);
    return stored.password;
  }
  return memPasswords.get(profileId) ?? DEFAULT_PASSWORDS[profileId] ?? profileId;
}

router.post("/profiles/:profileId/auth", async (req, res) => {
  const { profileId } = req.params;
  if (!VALID_PROFILES.includes(profileId)) return res.status(400).json({ error: "Perfil inválido" });
  const { password } = req.body as { password?: string };
  if (!password) return res.status(400).json({ error: "Senha obrigatória" });
  const current = await getCurrentPassword(profileId);
  return password === current ? res.json({ ok: true }) : res.status(401).json({ error: "Senha incorreta" });
});

router.put("/profiles/:profileId/password", async (req, res) => {
  const { profileId } = req.params;
  if (!VALID_PROFILES.includes(profileId)) return res.status(400).json({ error: "Perfil inválido" });
  const { oldPassword, newPassword } = req.body as { oldPassword?: string; newPassword?: string };
  if (!oldPassword || !newPassword) return res.status(400).json({ error: "Campos obrigatórios ausentes" });
  if (newPassword.length < 4) return res.status(400).json({ error: "A nova senha deve ter pelo menos 4 caracteres" });
  const current = await getCurrentPassword(profileId);
  if (oldPassword !== current) return res.status(401).json({ error: "Senha atual incorreta" });

  memPasswords.set(profileId, newPassword);
  await writeJson(`profiles/${profileId}/password.json`, { password: newPassword });
  return res.json({ ok: true });
});

export default router;
