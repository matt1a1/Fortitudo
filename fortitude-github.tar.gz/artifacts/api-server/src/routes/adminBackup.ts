import { Router } from "express";
import { VALID_PROFILES, DEFAULT_PASSWORDS, memData, memPasswords } from "../store";
import { readJson } from "../lib/storage";

const router = Router();
const ADMIN_PASSWORD = "Maraca";

router.post("/admin/backup", async (req, res) => {
  const { password } = req.body as { password?: string };
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Acesso negado" });

  const profiles: Record<string, unknown> = {};

  for (const id of VALID_PROFILES) {
    const [dataStored, pwStored] = await Promise.all([
      readJson<Record<string, unknown>>(`profiles/${id}/data.json`),
      readJson<{ password: string }>(`profiles/${id}/password.json`),
    ]);

    const data = dataStored ?? (memData.get(id) as Record<string, unknown> | undefined);
    const pw = pwStored?.password ?? memPasswords.get(id) ?? DEFAULT_PASSWORDS[id] ?? "(não definida)";

    const tabs = Array.isArray(data?.["__tabs__"]) ? data["__tabs__"] : [];
    const entries: Record<string, unknown[]> = {};
    if (data) {
      for (const key of Object.keys(data)) {
        if (key === "__tabs__" || key === "__savedAt__") continue;
        const val = data[key];
        if (Array.isArray(val)) entries[key] = val;
      }
    }

    profiles[id] = { senha: pw, abas: tabs, conteudo: entries };
  }

  return res.json({ backup_gerado_em: new Date().toISOString(), versao: "3.0", perfis: profiles });
});

export default router;
