export const VALID_PROFILES = ["fortitudo", "temperantia", "prudentia", "iustitia"];

export const DEFAULT_PASSWORDS: Record<string, string> = {
  fortitudo:   "fortitudeomelhor68",
  temperantia: "temperantia42",
  prudentia:   "prudentia15",
  iustitia:    "iustitia73",
};

const EMPTY_DATA = () => ({ anotacoes: [], cameras: [], enigmas: [], virtudes: [], npc: [] });

export const memData      = new Map<string, unknown>(VALID_PROFILES.map(id => [id, EMPTY_DATA()]));
export const memPasswords = new Map<string, string>(Object.entries(DEFAULT_PASSWORDS));
export const memAudit: Array<{ id: number; profileId: string; eventType: string; description: string; createdAt: Date }> = [];
let auditSeq = 1;

export function addMemAudit(profileId: string, eventType: string, description: string) {
  memAudit.unshift({ id: auditSeq++, profileId, eventType, description, createdAt: new Date() });
  if (memAudit.length > 500) memAudit.pop();
}
