import { Storage } from "@google-cloud/storage";

const REPLIT_SIDECAR_ENDPOINT = "http://127.0.0.1:1106";

const storage = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${REPLIT_SIDECAR_ENDPOINT}/token`,
    type: "external_account",
    credential_source: {
      url: `${REPLIT_SIDECAR_ENDPOINT}/credential`,
      format: {
        type: "json",
        subject_token_field_name: "access_token",
      },
    },
    universe_domain: "googleapis.com",
  } as Record<string, unknown>,
  projectId: "",
});

const bucketId = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;

function getBucket() {
  if (!bucketId) return null;
  return storage.bucket(bucketId);
}

export async function readJson<T>(path: string): Promise<T | null> {
  try {
    const b = getBucket();
    if (!b) return null;
    const file = b.file(path);
    const [exists] = await file.exists();
    if (!exists) return null;
    const [contents] = await file.download();
    return JSON.parse(contents.toString()) as T;
  } catch {
    return null;
  }
}

export async function writeJson(path: string, data: unknown): Promise<void> {
  try {
    const b = getBucket();
    if (!b) return;
    await b.file(path).save(JSON.stringify(data), { contentType: "application/json" });
  } catch (err) {
    console.error("Object Storage write error:", err);
  }
}
